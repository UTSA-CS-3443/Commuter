package menu.Model;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.OutputStream;
import java.io.InputStream;
import java.net.Socket;
import java.util.Scanner;


public class Client {


    public Client(String data) throws IOException {
        Socket sock = new Socket("127.0.0.1", 9090);
        OutputStream ostream = sock.getOutputStream();
        PrintWriter out = new PrintWriter(ostream, true);
        out.println(data);
    }
}
