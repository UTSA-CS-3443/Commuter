###&emsp;&emsp;&emsp;Classes
```
        public class Splash extends Application{

        }
```
###&emsp;&emsp;&emsp;Methods
```
        public static void main(String[] args){}
        public void start(Stage primaryStage) throws Exception{}
```
###&emsp;&emsp;&emsp;Variables
```
         private Stage stage;
         private Scene scene;
         public ImageView image;
         public Pane pane;
```